# FIND IT

Lost and Found Management System project.

## Run on this computer

1. Install [Node.js 22+](https://nodejs.org/) (LTS is recommended).
2. Open a terminal in this folder.
3. Install the packages (first run only), then start the server:

```powershell
npm.cmd install
node src/server.js
```

4. Keep the terminal open and visit [http://localhost:3000](http://localhost:3000).
5. To stop the server, focus its terminal and press `Ctrl+C`.

In VS Code, the FIND IT server also starts automatically when you open this
folder. If VS Code asks whether to allow automatic tasks, allow them for this
workspace. Keep the server task running while using the site; close the task to
stop it. If port 3000 is already in use, stop the other server using that port
before starting FIND IT.

On the first run, the app creates an administrator and a demo student with unique,
random passwords. Their login details are printed once in the server terminal.
Save the administrator password securely; passwords are stored as bcrypt hashes
in SQLite (`data/findit.db`).

## What is included

- Email registration and login
- Profile edits (public username, photo, password)
- Lost and found threads with image uploads
- Filters: category, lost/found type, title A–Z, latest upload
- Claim requests with optional image proof and admin verification
- Item status: reported, claimed, returned, closed
- Admin dashboard pages for overview, claims, accounts, threads, and archive management
- Account role management and reports
- Deleted accounts, threads, and related claims are stored in `data/findit_archive.db` for admin recovery
- FAQs and Terms pages

Project documentation is in the `docs` folder.
